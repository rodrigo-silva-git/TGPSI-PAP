package com.example.rodas.hs001;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by rodri on 17/01/2018.
 */

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "homservs.db";// Nome da Base de Dados
    public static final String TABLE_NAME = "user";// Nome da tabela
    public static final String COL_1 = "ID";//Coluna 1 -> ID
    public static final String COL_2 = "Usermame";// Coluna 2 -> Nome de Utilizador
    public static final String COL_3 = "Password";// Coluna 3 -> Password
    public static final String COL_4 = "Email";// Coluna 4 -> Email

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
        SQLiteDatabase db = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME +" (ID INTEGEGER PRIMARY KEY AUTOINCREMENT,Username TEXT, Password TEXT, EMAIL TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(db);
    }
}
