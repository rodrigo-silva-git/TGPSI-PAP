package com.example.rodas.hs001;

import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    DatabaseHelper myDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myDb = new DatabaseHelper(this);
    }
}

/*
TODO
    Acabar de ver o tutorial sobre SQLite:
        https://www.youtube.com/watch?annotation_id=annotation_2120971985&feature=iv&src_vid=cp2rL3sAFmI&v=p8TaTgr4uKM
    Compreender como funcionam as bases de dados em Android
 */
